#' @useDynLib tidygraph
#' @importFrom Rcpp sourceCpp
#' @keywords internal
'_PACKAGE'
