context("map")

test_that("TODO", {
  expect_equal(2 * 2, 4)
})
